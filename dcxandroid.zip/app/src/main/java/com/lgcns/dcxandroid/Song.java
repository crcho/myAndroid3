package com.lgcns.dcxandroid;

public class Song {
    int id;
    int rank;
    String title;
    String singer;
    String imageUrl;
}
