package com.lgcns.dcxandroid;

public class Detail {
    int id;
    String title;
    String singer;
    String melodizer;
    String lyricist;
    String genre;
}
